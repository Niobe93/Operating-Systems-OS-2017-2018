#include "Clock.h"
#include "Processor.h"
// #include "ComputerSystem.h"
#define INTERVALBETWEENINTERRUPS 5
int tics=0;

void Processor_RaiseInterrupt(const unsigned int);


void Clock_Update() {

	tics++;
	if (Clock_GetTime()%INTERVALBETWEENINTERRUPS==0){ //si los tics == cte entonces interrp
	Processor_RaiseInterrupt(CLOCKINT_BIT);
	} 
		
    
}

int Clock_GetTime() {

	return tics;
}
